screenshot of story
